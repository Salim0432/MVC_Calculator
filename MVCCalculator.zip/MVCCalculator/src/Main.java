import controller.BinaryCalculatorController;
import controller.ScientificCalculatorController;
import controller.SimpleCalculatorController;
import model.CalculatorModel;
import view.BinaryCalculatorView;
import view.ScientificCalculatorView;
import view.SimpleCalculatorView;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;


public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::createAndShowSelector);
    }

    private static void createAndShowSelector() {
        CalculatorModel model = new CalculatorModel();

        SimpleCalculatorView    simpleView     = new SimpleCalculatorView();
        BinaryCalculatorView    binaryView     = new BinaryCalculatorView();
        ScientificCalculatorView scientificView = new ScientificCalculatorView();

        new SimpleCalculatorController(model, simpleView);
        new BinaryCalculatorController(model, binaryView);
        new ScientificCalculatorController(model, scientificView);

        JFrame selector = new JFrame("MVC Calculator – Choose a View");
        selector.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(new EmptyBorder(30, 40, 30, 40));
        panel.setBackground(new Color(230, 235, 250));

        JLabel title = new JLabel("MVC Calculator Suite", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(33, 33, 100));
        panel.add(title, BorderLayout.NORTH);

        JLabel sub = new JLabel("Select a calculator to open:", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(Color.DARK_GRAY);

        JPanel btnPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        btnPanel.setOpaque(false);

        JButton btnSimple = makeBtn("Simple Calculator",     new Color(50, 100, 200));
        JButton btnBinary = makeBtn("Binary Calculator",     new Color(40, 130, 40));
        JButton btnSci    = makeBtn("Scientific Calculator", new Color(100, 30, 160));

        btnSimple.addActionListener(e -> {
            simpleView.setLocationRelativeTo(selector);
            simpleView.setVisible(true);
        });
        btnBinary.addActionListener(e -> {
            binaryView.setLocationRelativeTo(selector);
            binaryView.setVisible(true);
        });
        btnSci.addActionListener(e -> {
            scientificView.setLocationRelativeTo(selector);
            scientificView.setVisible(true);
        });

        btnPanel.add(btnSimple);
        btnPanel.add(btnBinary);
        btnPanel.add(btnSci);

        JPanel center = new JPanel(new BorderLayout(8, 8));
        center.setOpaque(false);
        center.add(sub,      BorderLayout.NORTH);
        center.add(btnPanel, BorderLayout.CENTER);
        panel.add(center, BorderLayout.CENTER);

        JLabel credit = new JLabel("Architecture: Model–View–Controller (MVC) | Java Swing", SwingConstants.CENTER);
        credit.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        credit.setForeground(Color.GRAY);
        panel.add(credit, BorderLayout.SOUTH);

        selector.add(panel);
        selector.pack();
        selector.setMinimumSize(new Dimension(340, 280));
        selector.setLocationRelativeTo(null);
        selector.setVisible(true);
    }

    private static JButton makeBtn(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBorder(new EmptyBorder(12, 20, 12, 20));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
