package model;

public class CalculatorModel {

    private double result;
    private String errorMessage;

    public CalculatorModel() {
        this.result = 0;
        this.errorMessage = "";
    }


    public double add(double a, double b) {
        result = a + b;
        return result;
    }

    public double subtract(double a, double b) {
        result = a - b;
        return result;
    }

    public double multiply(double a, double b) {
        result = a * b;
        return result;
    }

    public double divide(double a, double b) {
        if (b == 0) {
            errorMessage = "Error: Division by zero";
            return Double.NaN;
        }
        errorMessage = "";
        result = a / b;
        return result;
    }


    public double sin(double a) {
        result = Math.sin(Math.toRadians(a));
        return result;
    }

    public double cos(double a) {
        result = Math.cos(Math.toRadians(a));
        return result;
    }

    public double tan(double a) {
        if (Math.cos(Math.toRadians(a)) == 0) {
            errorMessage = "Error: tan undefined";
            return Double.NaN;
        }
        errorMessage = "";
        result = Math.tan(Math.toRadians(a));
        return result;
    }

    public double sqrt(double a) {
        if (a < 0) {
            errorMessage = "Error: Square root of negative number";
            return Double.NaN;
        }
        errorMessage = "";
        result = Math.sqrt(a);
        return result;
    }

    public double power(double base, double exp) {
        result = Math.pow(base, exp);
        return result;
    }

    public double log(double a) {
        if (a <= 0) {
            errorMessage = "Error: log of non-positive number";
            return Double.NaN;
        }
        errorMessage = "";
        result = Math.log10(a);
        return result;
    }

    public double ln(double a) {
        if (a <= 0) {
            errorMessage = "Error: ln of non-positive number";
            return Double.NaN;
        }
        errorMessage = "";
        result = Math.log(a);
        return result;
    }

    public double factorial(int n) {
        if (n < 0) {
            errorMessage = "Error: Factorial of negative number";
            return Double.NaN;
        }
        errorMessage = "";
        long f = 1;
        for (int i = 2; i <= n; i++) f *= i;
        result = f;
        return result;
    }

   
    public boolean isValidBinary(String s) {
        return s != null && !s.isEmpty() && s.matches("[01]+");
    }

    
    public long binaryToDecimal(String binary) {
        return Long.parseLong(binary, 2);
    }

  
    public String decimalToBinary(long decimal) {
        if (decimal < 0) return "-" + Long.toBinaryString(-decimal);
        return Long.toBinaryString(decimal);
    }


    public double getResult() { return result; }

    public String getErrorMessage() { return errorMessage; }

    public boolean hasError() { return !errorMessage.isEmpty(); }
}
