package controller;

import model.CalculatorModel;
import view.SimpleCalculatorView;


public class SimpleCalculatorController {

    private final CalculatorModel model;
    private final SimpleCalculatorView view;

    public SimpleCalculatorController(CalculatorModel model, SimpleCalculatorView view) {
        this.model = model;
        this.view  = view;

        this.view.setController(this);
    }

    public void calculate() {
        String input1 = view.getInput1();
        String input2 = view.getInput2();
        String op     = view.getSelectedOperation();

        double a, b = 0;
        try {
            a = Double.parseDouble(input1);
        } catch (NumberFormatException e) {
            view.showError("Invalid first number: \"" + input1 + "\"");
            return;
        }

        boolean needsTwo = !op.equals("√") && !op.equals("abs");
        if (needsTwo) {
            try {
                b = Double.parseDouble(input2);
            } catch (NumberFormatException e) {
                view.showError("Invalid second number: \"" + input2 + "\"");
                return;
            }
        }

    
        double result;
        switch (op) {
            case "+":  result = model.add(a, b);      break;
            case "-":  result = model.subtract(a, b); break;
            case "×":  result = model.multiply(a, b); break;
            case "÷":  result = model.divide(a, b);   break;
            case "√":  result = model.sqrt(a);        break;
            case "abs":result = Math.abs(a);           break;
            default:
                view.showError("Unknown operation: " + op);
                return;
        }

        if (model.hasError() || Double.isNaN(result)) {
            view.showError(model.getErrorMessage());
        } else {
            
            if (result == Math.floor(result) && !Double.isInfinite(result)) {
                view.showResult(String.valueOf((long) result));
            } else {
                view.showResult(String.format("%.8f", result).replaceAll("0+$", "").replaceAll("\\.$", ".0"));
            }
        }
    }

    public void clear() {
        view.clearFields();
    }
}
