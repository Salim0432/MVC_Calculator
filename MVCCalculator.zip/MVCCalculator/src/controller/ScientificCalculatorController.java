package controller;

import model.CalculatorModel;
import view.ScientificCalculatorView;


public class ScientificCalculatorController {

    private final CalculatorModel model;
    private final ScientificCalculatorView view;

    public ScientificCalculatorController(CalculatorModel model, ScientificCalculatorView view) {
        this.model = model;
        this.view  = view;
        this.view.setController(this);
    }

    public void calculate() {
        String input1 = view.getInput1().trim();
        String input2 = view.getInput2().trim();
        String op     = view.getSelectedOperation();

        double a;
        try {
            a = Double.parseDouble(input1);
        } catch (NumberFormatException e) {
            view.showError("Invalid input: \"" + input1 + "\"");
            return;
        }

       
        boolean isUnary = op.equals("sin") || op.equals("cos") || op.equals("tan")
                       || op.equals("√")   || op.equals("log") || op.equals("ln")
                       || op.equals("n!");

        double result;

        if (isUnary) {
            switch (op) {
                case "sin": result = model.sin(a);              break;
                case "cos": result = model.cos(a);              break;
                case "tan": result = model.tan(a);              break;
                case "√":   result = model.sqrt(a);             break;
                case "log": result = model.log(a);              break;
                case "ln":  result = model.ln(a);               break;
                case "n!":
                    if (a != Math.floor(a) || a < 0) {
                        view.showError("Factorial requires a non-negative integer");
                        return;
                    }
                    result = model.factorial((int) a);
                    break;
                default:
                    view.showError("Unknown operation: " + op);
                    return;
            }
        } else {
           
            double b;
            try {
                b = Double.parseDouble(input2);
            } catch (NumberFormatException e) {
                view.showError("Invalid second input: \"" + input2 + "\"");
                return;
            }
            switch (op) {
                case "+":   result = model.add(a, b);      break;
                case "-":   result = model.subtract(a, b); break;
                case "×":   result = model.multiply(a, b); break;
                case "÷":   result = model.divide(a, b);   break;
                case "xʸ":  result = model.power(a, b);    break;
                default:
                    view.showError("Unknown operation: " + op);
                    return;
            }
        }

        if (model.hasError() || Double.isNaN(result)) {
            view.showError(model.getErrorMessage());
        } else {
            if (result == Math.floor(result) && !Double.isInfinite(result) && Math.abs(result) < 1e15) {
                view.showResult(String.valueOf((long) result));
            } else {
                view.showResult(String.format("%.10f", result).replaceAll("0+$", "").replaceAll("\\.$", ".0"));
            }
        }
    }

    public void clear() {
        view.clearFields();
    }
}
