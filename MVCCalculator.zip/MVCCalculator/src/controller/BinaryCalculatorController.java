package controller;

import model.CalculatorModel;
import view.BinaryCalculatorView;


public class BinaryCalculatorController {

    private final CalculatorModel model;
    private final BinaryCalculatorView view;

    public BinaryCalculatorController(CalculatorModel model, BinaryCalculatorView view) {
        this.model = model;
        this.view  = view;
        this.view.setController(this);
    }

    public void calculate() {
        String binA = view.getInput1().trim();
        String binB = view.getInput2().trim();
        String op   = view.getSelectedOperation();

        if (!model.isValidBinary(binA)) {
            view.showError("First input \"" + binA + "\" is not a valid binary number (use 0 and 1 only)");
            return;
        }

        boolean needsTwo = true;
        if (needsTwo && !model.isValidBinary(binB)) {
            view.showError("Second input \"" + binB + "\" is not a valid binary number (use 0 and 1 only)");
            return;
        }

        long a = model.binaryToDecimal(binA);
        long b = model.binaryToDecimal(binB);

        double result;
        switch (op) {
            case "+": result = model.add(a, b);      break;
            case "-": result = model.subtract(a, b); break;
            case "×": result = model.multiply(a, b); break;
            case "÷": result = model.divide(a, b);   break;
            default:
                view.showError("Unknown operation: " + op);
                return;
        }

        if (model.hasError() || Double.isNaN(result)) {
            view.showError(model.getErrorMessage());
        } else {
            long longResult = (long) result;
            String binaryResult = model.decimalToBinary(longResult);

            view.showResult(binaryResult + "  (decimal: " + longResult + ")");
            view.showDecimalEquation(a + " " + op + " " + b + " = " + longResult);
        }
    }

    public void clear() {
        view.clearFields();
    }
}
