package view;

import controller.ScientificCalculatorController;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * VIEW – Scientific Calculator
 * Extends the simple calculator with trigonometry, logarithms, power, factorial, etc.
 */
public class ScientificCalculatorView extends JFrame {

    private final JTextField    txtInput1   = new JTextField(12);
    private final JTextField    txtInput2   = new JTextField(12);
    private final JLabel        lblResult   = new JLabel("Result: —");
    private final JLabel        lblNote     = new JLabel("(trig. input in degrees)");
    private final JComboBox<String> cmbOp   = new JComboBox<>(new String[]{
        "+", "-", "×", "÷",
        "sin", "cos", "tan",
        "√", "log", "ln",
        "xʸ", "n!"
    });
    private final JButton btnCalc  = new JButton("Calculate");
    private final JButton btnClear = new JButton("Clear");

    private ScientificCalculatorController controller;

    public ScientificCalculatorView() {
        setTitle("Scientific Calculator");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        buildUI();
        pack();
        setLocationRelativeTo(null);
    }

    private void buildUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(new EmptyBorder(20, 20, 20, 20));
        main.setBackground(new Color(240, 240, 250));

        JLabel title = new JLabel("Scientific Calculator", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(60, 20, 120));
        main.add(title, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 7, 7, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("Operand 1 :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput1, gbc);

        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("Operation :"), gbc);
        gbc.gridx = 1; inputPanel.add(cmbOp, gbc);

        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(new JLabel("Operand 2 :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput2, gbc);

        // Note about unary operations
        lblNote.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblNote.setForeground(Color.GRAY);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        inputPanel.add(lblNote, gbc);

        main.add(inputPanel, BorderLayout.CENTER);

        // Update note dynamically
        cmbOp.addActionListener(e -> {
            String op = (String) cmbOp.getSelectedItem();
            boolean isUnary = op != null && (op.equals("sin") || op.equals("cos") || op.equals("tan")
                    || op.equals("√") || op.equals("log") || op.equals("ln") || op.equals("n!"));
            txtInput2.setEnabled(!isUnary);
            if (op != null && (op.equals("sin") || op.equals("cos") || op.equals("tan"))) {
                lblNote.setText("Angle in degrees");
            } else if (isUnary) {
                lblNote.setText("Operand 2 not used for this operation");
            } else {
                lblNote.setText("Enter both operands");
            }
        });

        // Result area
        lblResult.setFont(new Font("Courier New", Font.BOLD, 14));
        lblResult.setForeground(new Color(60, 20, 120));
        lblResult.setBorder(new CompoundBorder(
                new LineBorder(new Color(180, 150, 220), 1, true),
                new EmptyBorder(8, 12, 8, 12)));
        lblResult.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setOpaque(false);
        styleButton(btnCalc, new Color(100, 30, 160));
        styleButton(btnClear, new Color(180, 60, 60));
        btnPanel.add(btnCalc);
        btnPanel.add(btnClear);

        JPanel south = new JPanel(new BorderLayout(5, 5));
        south.setOpaque(false);
        south.add(lblResult, BorderLayout.CENTER);
        south.add(btnPanel,  BorderLayout.SOUTH);
        main.add(south, BorderLayout.SOUTH);

        btnCalc.addActionListener(e -> { if (controller != null) controller.calculate(); });
        btnClear.addActionListener(e -> { if (controller != null) controller.clear(); });

        KeyAdapter enter = new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && controller != null) controller.calculate();
            }
        };
        txtInput1.addKeyListener(enter);
        txtInput2.addKeyListener(enter);

        add(main);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBorder(new EmptyBorder(8, 22, 8, 22));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // ── View API ─────────────────────────────────────────────────────────────

    public void setController(ScientificCalculatorController c) { this.controller = c; }

    public String getInput1()            { return txtInput1.getText().trim(); }
    public String getInput2()            { return txtInput2.getText().trim(); }
    public String getSelectedOperation() { return (String) cmbOp.getSelectedItem(); }

    public void showResult(String result) {
        lblResult.setForeground(new Color(60, 20, 120));
        lblResult.setText("Result: " + result);
    }

    public void showError(String msg) {
        lblResult.setForeground(new Color(180, 30, 30));
        lblResult.setText(msg);
    }

    public void clearFields() {
        txtInput1.setText("");
        txtInput2.setText("");
        lblResult.setForeground(new Color(60, 20, 120));
        lblResult.setText("Result: —");
        txtInput1.requestFocus();
    }
}
