package view;

import controller.BinaryCalculatorController;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * VIEW – Binary Calculator
 * Accepts only binary (0/1) inputs and shows results in binary.
 * Delegates all computation to BinaryCalculatorController.
 */
public class BinaryCalculatorView extends JFrame {

    private final JTextField txtInput1      = new JTextField(14);
    private final JTextField txtInput2      = new JTextField(14);
    private final JLabel     lblResult      = new JLabel("Result (binary): —");
    private final JLabel     lblEquation    = new JLabel(" ");
    private final JComboBox<String> cmbOp   = new JComboBox<>(new String[]{"+", "-", "×", "÷"});
    private final JButton    btnCalc        = new JButton("Calculate");
    private final JButton    btnClear       = new JButton("Clear");

    private BinaryCalculatorController controller;

    public BinaryCalculatorView() {
        setTitle("Binary Calculator");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        buildUI();
        pack();
        setLocationRelativeTo(null);
    }

    private void buildUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(new EmptyBorder(20, 20, 20, 20));
        main.setBackground(new Color(240, 245, 240));

        JLabel title = new JLabel("Binary Calculator", SwingConstants.CENTER);
        title.setFont(new Font("Courier New", Font.BOLD, 18));
        title.setForeground(new Color(20, 80, 20));
        main.add(title, BorderLayout.NORTH);

        // Hint label
        JLabel hint = new JLabel("Enter binary numbers (digits 0 and 1 only)", SwingConstants.CENTER);
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(Color.GRAY);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("Binary A :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput1, gbc);

        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("Operation :"), gbc);
        gbc.gridx = 1; inputPanel.add(cmbOp, gbc);

        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(new JLabel("Binary B :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput2, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        inputPanel.add(hint, gbc);

        main.add(inputPanel, BorderLayout.CENTER);

        // Result area
        lblResult.setFont(new Font("Courier New", Font.BOLD, 14));
        lblResult.setForeground(new Color(10, 100, 10));
        lblResult.setBorder(new CompoundBorder(
                new LineBorder(new Color(150, 200, 150), 1, true),
                new EmptyBorder(8, 12, 8, 12)));
        lblResult.setHorizontalAlignment(SwingConstants.CENTER);

        lblEquation.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblEquation.setForeground(Color.DARK_GRAY);
        lblEquation.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setOpaque(false);
        styleButton(btnCalc, new Color(40, 130, 40));
        styleButton(btnClear, new Color(180, 60, 60));
        btnPanel.add(btnCalc);
        btnPanel.add(btnClear);

        JPanel south = new JPanel(new BorderLayout(3, 3));
        south.setOpaque(false);
        south.add(lblResult,   BorderLayout.NORTH);
        south.add(lblEquation, BorderLayout.CENTER);
        south.add(btnPanel,    BorderLayout.SOUTH);
        main.add(south, BorderLayout.SOUTH);

        btnCalc.addActionListener(e -> { if (controller != null) controller.calculate(); });
        btnClear.addActionListener(e -> { if (controller != null) controller.clear(); });

        KeyAdapter enter = new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && controller != null) controller.calculate();
            }
        };
        txtInput1.addKeyListener(enter);
        txtInput2.addKeyListener(enter);

        add(main);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBorder(new EmptyBorder(8, 22, 8, 22));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // ── View API ─────────────────────────────────────────────────────────────

    public void setController(BinaryCalculatorController c) { this.controller = c; }

    public String getInput1()            { return txtInput1.getText().trim(); }
    public String getInput2()            { return txtInput2.getText().trim(); }
    public String getSelectedOperation() { return (String) cmbOp.getSelectedItem(); }

    public void showResult(String result) {
        lblResult.setForeground(new Color(10, 100, 10));
        lblResult.setText("Result: " + result);
    }

    public void showDecimalEquation(String eq) {
        lblEquation.setText("Decimal: " + eq);
    }

    public void showError(String msg) {
        lblResult.setForeground(new Color(180, 30, 30));
        lblResult.setText(msg);
        lblEquation.setText(" ");
    }

    public void clearFields() {
        txtInput1.setText("");
        txtInput2.setText("");
        lblResult.setForeground(new Color(10, 100, 10));
        lblResult.setText("Result (binary): —");
        lblEquation.setText(" ");
        txtInput1.requestFocus();
    }
}
