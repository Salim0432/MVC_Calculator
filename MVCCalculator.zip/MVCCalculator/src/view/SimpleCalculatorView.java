package view;

import controller.SimpleCalculatorController;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * VIEW – Simple Calculator
 * Displays the UI for basic arithmetic. Delegates all logic to the controller.
 */
public class SimpleCalculatorView extends JFrame {

    // ── UI Components ────────────────────────────────────────────────────────
    private final JTextField txtInput1    = new JTextField(12);
    private final JTextField txtInput2    = new JTextField(12);
    private final JLabel     lblResult    = new JLabel("Result: —");
    private final JComboBox<String> cmbOp = new JComboBox<>(new String[]{"+", "-", "×", "÷", "√", "abs"});
    private final JButton    btnCalc      = new JButton("Calculate");
    private final JButton    btnClear     = new JButton("Clear");

    private SimpleCalculatorController controller;

    public SimpleCalculatorView() {
        setTitle("Simple Calculator");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        buildUI();
        pack();
        setLocationRelativeTo(null);
    }

    private void buildUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(new EmptyBorder(20, 20, 20, 20));
        main.setBackground(new Color(245, 245, 250));

        // Title
        JLabel title = new JLabel("Simple Calculator", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(33, 33, 100));
        main.add(title, BorderLayout.NORTH);

        // Input panel
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("Number 1 :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput1, gbc);

        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("Operation :"), gbc);
        gbc.gridx = 1; inputPanel.add(cmbOp, gbc);

        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(new JLabel("Number 2 :"), gbc);
        gbc.gridx = 1; inputPanel.add(txtInput2, gbc);

        main.add(inputPanel, BorderLayout.CENTER);

        // Result area
        lblResult.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblResult.setForeground(new Color(20, 100, 20));
        lblResult.setBorder(new CompoundBorder(
                new LineBorder(new Color(180, 180, 220), 1, true),
                new EmptyBorder(8, 12, 8, 12)));
        lblResult.setHorizontalAlignment(SwingConstants.CENTER);

        // Button panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setOpaque(false);
        styleButton(btnCalc, new Color(50, 100, 200));
        styleButton(btnClear, new Color(180, 60, 60));
        btnPanel.add(btnCalc);
        btnPanel.add(btnClear);

        JPanel south = new JPanel(new BorderLayout(5, 5));
        south.setOpaque(false);
        south.add(lblResult, BorderLayout.CENTER);
        south.add(btnPanel, BorderLayout.SOUTH);
        main.add(south, BorderLayout.SOUTH);

        // Action listeners — delegate to controller
        btnCalc.addActionListener(e -> { if (controller != null) controller.calculate(); });
        btnClear.addActionListener(e -> { if (controller != null) controller.clear(); });

        // Allow pressing Enter in input fields
        KeyAdapter enter = new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && controller != null) controller.calculate();
            }
        };
        txtInput1.addKeyListener(enter);
        txtInput2.addKeyListener(enter);

        add(main);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBorder(new EmptyBorder(8, 22, 8, 22));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // ── View API (used by Controller) ────────────────────────────────────────

    public void setController(SimpleCalculatorController c) { this.controller = c; }

    public String getInput1()             { return txtInput1.getText().trim(); }
    public String getInput2()             { return txtInput2.getText().trim(); }
    public String getSelectedOperation()  { return (String) cmbOp.getSelectedItem(); }

    public void showResult(String result) {
        lblResult.setForeground(new Color(20, 100, 20));
        lblResult.setText("Result: " + result);
    }

    public void showError(String msg) {
        lblResult.setForeground(new Color(180, 30, 30));
        lblResult.setText(msg);
    }

    public void clearFields() {
        txtInput1.setText("");
        txtInput2.setText("");
        lblResult.setForeground(new Color(20, 100, 20));
        lblResult.setText("Result: —");
        txtInput1.requestFocus();
    }
}
